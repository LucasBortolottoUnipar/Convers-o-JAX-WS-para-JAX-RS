package br.unipar.uniclinica.uniclinica.domain;

public enum MotivoCancelamento {
    PACIENTE_DESISTIU,
    MEDICO_CANCELOU,
    OUTROS
}
