package br.unipar.uniclinica.uniclinica;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/api")
public class UniclinicaApplication extends Application {

}
